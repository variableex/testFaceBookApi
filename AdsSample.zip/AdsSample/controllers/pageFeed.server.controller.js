var pageFeedController = (function () {

    'use strict';

    const https = require('https');

    function pageFeedModule() { }

    var _p = pageFeedModule.prototype;

    _p.getData = function (request, responce) {

        const https = require('https');

        let access_token =request.body.access_token;

        const options = {
            protoco: 'https',
            hostname: 'graph.facebook.com',
            port: 443,
            path: '/v6.0/148040569123339/feed?access_token='+access_token,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        };


        const req = https.request(options, (res) => {
            let resData = '';

            res.on('data', (chunk) => {
                resData += chunk;
            });

            res.on('end', () => {
                console.log(resData);
                responce.status(200).json({
                    status: true,
                    message: "pageFeed Info",
                    data: JSON.parse(resData)
                });
            });

        }).on("error", (err) => {
            console.log("Error: ", err.message);
        });

        req.end();
    };

    _p.postData = function (request, responce) {

        let access_token =request.body.access_token;

        const https = require('https');

        const data = JSON.stringify({
            message: request.body.message
        });

        const options = {
            protoco: 'https',
            hostname: 'graph.facebook.com',
            port: 443,
            path: '/v6.0/148040569123339/feed?access_token='+access_token,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        };


        const req = https.request(options, (res) => {
            let resData = '';

            res.on('data', (chunk) => {
                resData += chunk;
            });

            res.on('end', () => {
                console.log(resData);
                responce.status(200).json({
                    status: true,
                    message: "pageFeed Info",
                    data: JSON.parse(resData)
                });
            });

        }).on("error", (err) => {
            console.log("Error: ", err.message);
        });

        req.write(data);
        req.end();
    };

    _p.deleteData = function (request, responce) {

        let access_token =request.body.access_token;
        let deleteId = request.body.deleteId

        const https = require('https');

        const data = JSON.stringify({
            message: request.body.message
        });

        const options = {
            protoco: 'https',
            hostname: 'graph.facebook.com',
            port: 443,
            path: '/v6.0/'+deleteId+'?access_token='+access_token,
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        };


        const req = https.request(options, (res) => {
            let resData = '';

            res.on('data', (chunk) => {
                resData += chunk;
            });

            res.on('end', () => {
                console.log(resData);
                responce.status(200).json({
                    status: true,
                    message: "pageFeed Info",
                    data: JSON.parse(resData)
                });
            });

        }).on("error", (err) => {
            console.log("Error: ", err.message);
        });

        req.write(data);
        req.end();
    };

    return {
        getData:_p.getData,
        postData:_p.postData,
        deleteData:_p.deleteData
    };
})();

module.exports = pageFeedController;