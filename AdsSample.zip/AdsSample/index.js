const express = require('express');
const app = express();
var cors = require('cors')
const bodyParser = require('body-parser');
    app.use(cors())
    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.json());

    var pageFeed = require('./routes/pageFeed.route')
    app.use('/api/pageFeed',pageFeed)

module.exports = app;