var pageFeedRouters = (function () {

    'use strict';

    var express = require('express'),
        pageFeedController = require('../controllers/pageFeed.server.controller'),
        pageFeedRouter = express.Router();

    pageFeedRouter.route('/getData').post(pageFeedController.getData);
    pageFeedRouter.route('/postData').post(pageFeedController.postData);
    pageFeedRouter.route('/deleteData').post(pageFeedController.deleteData);

    return pageFeedRouter;

})();

module.exports = pageFeedRouters;