// /**
//  * Copyright (c) 2017-present, Facebook, Inc.
//  * All rights reserved.
//  *
//  * This source code is licensed under the license found in the
//  * LICENSE file in the root directory of this source tree.
//  * @flow
//  */

// const bizSdk = require('facebook-nodejs-business-sdk');
// const AdAccount = bizSdk.AdAccount;
// const AdsInsights = bizSdk.AdsInsights;

// let access_token = 'EAADwKlkg5qgBAOGiFbPrQmM36qyMO9VmciSReXf5OScvYTlps0huiaE5ReTv0UwU4gT3APXgZCZARV6dhWykhT2J5JiJNtLVJ10V5oMaycKkTCKAkPq2YGddNg70czyBFMwCZBIdCcaK8HXH9c6ZB4mJYbKVmDlV3cnE4HSBftoJbba2jZBEP81U1Gu1qFH0ZD';
// let ad_account_id = 'act_274872596859465';
// let app_secret = 'b6891b68c2935ad0bee30ee620f7d3bb';
// let app_id = '264064674621096';
// const api = bizSdk.FacebookAdsApi.init(access_token);
// const account = new AdAccount(ad_account_id);
// const showDebugingInfo = true; // Setting this to true shows more debugging info.
// if (showDebugingInfo) {
//   api.setDebug(true);
// }

// let ads_insights;
// let ads_insights_id;

// const logApiCallResult = (apiCallName, data) => {
//   console.log(apiCallName);
//   if (showDebugingInfo) {
//     console.log('Data:' + JSON.stringify(data));
//   }
// };

// const fields = [
//   // 'impressions_auto_refresh',
//   // 'cost_per_result',
//   // 'actions:like',
//   // 'actions:comment',
//   'ad_format_asset', 'age', 'body_asset', 'call_to_action_asset', 'country', 'description_asset', 'gender', 'image_asset', 'impression_device', 'link_url_asset', 'product_id', 'region', 'title_asset', 'video_asset', 'dma', 'frequency_value', 'hourly_stats_aggregated_by_advertiser_time_zone', 'hourly_stats_aggregated_by_audience_time_zone', 'place_page_id', 'publisher_platform', 'platform_position', 'device_platform'
// ];
// const params = {
//   'level' : 'campaign',
//   'filtering' : [],
//   'breakdowns' : ['ad_id'],
//   'time_range' : {'since':'2020-03-11','until':'2020-04-10'},
// };
// //  (new AdAccount(ad_account_id)).getInsights(
// //   fields,
// //   params
// // )
// // .then((result) => {
// //   logApiCallResult('ads_insights api call complete.', result);
// //   ads_insights_id = result[0].id;
// // })
// // .catch((error) => {
// //   console.log(error);
// // });


let access_token = "EAADwKlkg5qgBAKkqDeilgp04ZB2ZAHhi1e4AmBHebSVA3uzD13Ln8jrKuwSmZCRlZBqEErRSvibUsvUPvDOugQUqLpUxKXbqQQPvwC7ckUrzEMOjtdb61ppfcUwZBrKMVJ51dS27Dw5ObO4CBlsUJbzHgxTVjaNvxJQr07apiA9iayLz4G35bOQEbK0eiQa4ZD";


// const https = require('https')
// const options = {
//   hostname: 'facebook.com',
//   path: 'https://graph.facebook.com/v6.0/148040569123339/feed?access_token='+access_token,
//   method: 'GET'
// }

// const req = https.request(options, res => {
//   console.log(`statusCode: ${res}`)

//   res.on('data', d => {
//     process.stdout.write(d)
//   })
// });


// req.on('error', error => {
//   console.error(error)
// })


req.write(data)
// req.end()
 
const https = require('https')

const data = JSON.stringify({
  message: 'Buy the milk'
})

const optionspost = {
  hostname: 'facebook.com',
  path: 'https://graph.facebook.com/v6.0/148040569123339/feed?access_token='+access_token,
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
}

const req = https.request(optionspost, res => {
  console.log(`statusCode: ${res.statusCode}`)

  res.on('data', d => {
    process.stdout.write(d)
  })
})

req.on('error', error => {
  console.error(error)
})

req.write(data)
req.end()